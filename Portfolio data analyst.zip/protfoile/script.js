// script.js - Interactions for the portfolio
// - Mobile nav toggle
// - Smooth scrolling
// - Scroll reveal using IntersectionObserver
// - Simple contact form handling (no backend)
// - Custom cursor effect (dot + halo) with hover interactions

(function () {
	'use strict';

	// helpers
	const $ = (sel, root = document) => root.querySelector(sel);
	const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

	document.addEventListener('DOMContentLoaded', () => {
		// Footer year
		const yearEl = $('#year');
		if (yearEl) yearEl.textContent = new Date().getFullYear();

		// Mobile nav toggle
		const navToggle = $('.nav-toggle');
		const navList = $('.nav-list');
		if (navToggle && navList) {
			navToggle.addEventListener('click', () => navList.classList.toggle('open'));
		}

		// Smooth internal anchor scrolling
		$$('a[href^="#"]').forEach(anchor => {
			anchor.addEventListener('click', function (e) {
				const href = this.getAttribute('href');
				if (href && href.startsWith('#')) {
					e.preventDefault();
					const target = document.querySelector(href);
					if (target) target.scrollIntoView({ behavior: 'smooth', block: 'start' });
					if (navList && navList.classList.contains('open')) navList.classList.remove('open');
				}
			});
		});

		// Scroll reveal
		const revealObserver = new IntersectionObserver((entries, obs) => {
			entries.forEach(entry => {
				if (entry.isIntersecting) {
					entry.target.classList.add('in-view');
					obs.unobserve(entry.target);
				}
			});
		}, { threshold: 0.12 });
		$$('.reveal').forEach(el => revealObserver.observe(el));

		// Contact form handling (client-side only)
		const contactForm = $('#contactForm');
		const formStatus = $('#formStatus');
		if (contactForm) {
			contactForm.addEventListener('submit', (e) => {
				e.preventDefault();
				const name = contactForm.name.value.trim();
				const email = contactForm.email.value.trim();
				const message = contactForm.message.value.trim();
				if (!name || !email || !message) {
					if (formStatus) formStatus.textContent = 'Please fill in all fields.';
					return;
				}
				if (formStatus) formStatus.textContent = 'Sending...';
				setTimeout(() => {
					if (formStatus) formStatus.textContent = 'Message sent. Thank you! I will get back to you soon.';
					contactForm.reset();
				}, 900);
			});
		}

		// Initialize custom cursor on hover-capable devices
		if (window.matchMedia && window.matchMedia('(hover: hover)').matches) initCustomCursor();
	});

	// Custom cursor implementation
	function initCustomCursor() {
		const dot = document.createElement('div');
		dot.className = 'cursor-dot';
		const outer = document.createElement('div');
		outer.className = 'cursor-outer';
		document.body.appendChild(outer);
		document.body.appendChild(dot);

		let mouseX = window.innerWidth / 2, mouseY = window.innerHeight / 2;
		let outerX = mouseX, outerY = mouseY;
		const ease = 0.16;

		// pointer move -> position dot immediately, outer eases in RAF loop
		window.addEventListener('pointermove', (e) => {
			mouseX = e.clientX;
			mouseY = e.clientY;
			dot.style.transform = `translate(${mouseX}px, ${mouseY}px) translate(-50%, -50%)`;
			dot.style.opacity = '1';
			outer.style.opacity = '1';
		});

		window.addEventListener('pointerdown', () => document.body.classList.add('cursor-down'));
		window.addEventListener('pointerup', () => document.body.classList.remove('cursor-down'));

		// Add hover targets
		const hoverSelectors = ['a', 'button', '.btn', '.btn-sm', '.nav-list a', 'input', 'textarea', '.project-card'];
		hoverSelectors.forEach(sel => {
			$$(sel).forEach(el => {
				el.addEventListener('pointerenter', () => document.body.classList.add('cursor-hover'));
				el.addEventListener('pointerleave', () => document.body.classList.remove('cursor-hover'));
			});
		});

		// RAF loop for outer easing
		function render() {
			outerX += (mouseX - outerX) * ease;
			outerY += (mouseY - outerY) * ease;
			outer.style.transform = `translate(${outerX}px, ${outerY}px) translate(-50%, -50%)`;
			requestAnimationFrame(render);
		}
		requestAnimationFrame(render);

		// handle leaving/entering window
		window.addEventListener('pointerleave', () => { outer.style.opacity = '0'; dot.style.opacity = '0'; });
		window.addEventListener('pointerenter', () => { outer.style.opacity = '1'; dot.style.opacity = '1'; });
	}

})();
